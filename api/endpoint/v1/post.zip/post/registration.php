<?php

class endpoint_v1_post_registration extends Endpoint_REST{
    public $model_class = 'User';
    public $allow_list=false;
    public $allow_list_one=false;
    public $allow_add=true;
    public $allow_edit=false;
    public $allow_delete=false;

    function init(){
    	parent::init();

    }

    function get(){
        return "you are not allow to access";
    }

    function _model(){
        return parent::_model();
    }

    function authenticate(){
        return true;
    }
    /**
     * Because it's not really defined which of the two is used for updating
     * the resource, Agile Toolkit will support put_post identically. Both
     * of the requests are idempotent.
     *
     * As you extend this class and redefine methods, you should properly
     * use POST or PUT. See http://stackoverflow.com/a/2691891/204819
     *
     * @param  [type] $data [description]
     * @return [type]       [description]
    */

    function put_post($data){
        $this->validateParam($data);

        $m = $this->model;

        if($m->loaded()){
            if(!$this->allow_edit)throw $this->exception('Editing is not allowed');
            $data=$this->_input($data, $this->allow_edit);
        }else{
            if(!$this->allow_add)throw $this->exception('Adding is not allowed');
            $data=$this->_input($data, $this->allow_add);
        }
        
    
        if($data['access_token']){
            if(!in_array($data['social'], ['Facebook','Google']))
                return json_encode(
                            array(
                                'status'=>"failed",
                                'message'=>"login with ".$data['social']." social media not allowed"
                            ));

            $controller = $this->add('Controller_'.$data['social'],array('hfrom'=>$data['social'],'access_token'=>$data['access_token'],'call_loginfunction'=>false));
            $new_user_model = $controller->loginStatus($data['access_token']);

            if(!$new_user_model['dob'])
                $new_user_model['dob'] = $data['dob'];
            if(!$new_user_model['mobile'])
                $new_user_model['mobile'] = $data['mobile'];

            $new_user_model->save();
            $m = $this->model = $new_user_model;
         }else{

            //check email is valid 
            if(!filter_var($data['email'], FILTER_VALIDATE_EMAIL)){
                return json_encode(array('status'=>"failed",'message'=>"email id is not valid"));
            }
            
            // check mobile is valid
            preg_match_all("/^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[789]\d{9}$/", $data['mobile'], $matches);
            if(!count($matches[0]))
                return json_encode(array('status'=>'failed','message'=>"mobile number is not valid"));
            
            if($m->checkEmailMobileExit($data['mobile'],$data['mobile'])){
                return json_encode(
                                array(
                                    "status"=>"failed",
                                    'message'=>"your email or mobile number is already registered"
                                ));
            }

            $m->set($data);
            $md5_access_token = md5(uniqid($m['email']."-".$m['created_at'], true));
            $m['social_access_token'] = $md5_access_token;
            $m['is_active'] = 1;
            $m['social_app'] = "HungryDunia";
            $m['type'] = 'user';
            $m->save();
        }

        // sending email after user savd into database        
        try{
            // $m->sendAppRegistrationWelcomeMail();
            // $m->sendOTP();
            return json_encode(array(
                                'status'=>"success",
                                "message"=>"your account has been created successfully",
                                'access_token'=>$m['social_access_token']
                            ));
        }catch(\Exception $e){
            return json_encode(array('status'=>'failed','message'=>"Internet/Server Problem"));
        }
	}

	function delete($data){
        return "you are not allow to access";
	}

    function validateParam($data){
        
        $required_param = ['name','email','created_at','dob','mobile','received_newsletter','social','social_content','password'];
        foreach ($required_param as $param) {
            if(!array_key_exists($param, $data)){
                echo "Param = $param Error 1001";
                exit;
            }
        }

                
    }

}